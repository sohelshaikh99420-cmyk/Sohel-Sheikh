# Sohel Sheikh Portfolio

Premium responsive portfolio for Sohel Sheikh — Video Editor & Videographer.

## Included
- Fast single-page portfolio
- WhatsApp enquiry form
- Instagram / email / phone quick actions
- SEO meta + structured data
- Favicon
- Social preview image
- 404 page
- robots.txt + sitemap.xml

Deploy with GitHub Pages from the `main` branch and repository root.
