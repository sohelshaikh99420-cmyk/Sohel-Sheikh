
const q=(s,c=document)=>c.querySelector(s), qa=(s,c=document)=>[...c.querySelectorAll(s)];
const body=document.body;
const menuBtn=q('#menuBtn'), nav=q('#nav');
const modal=q('#modal'), modalImg=q('#modalImg'), modalTitle=q('#modalTitle'), modalDesc=q('#modalDesc');
const toast=q('#toast');

function showToast(message='Done'){
  if(!toast) return;
  toast.textContent=message;
  toast.classList.remove('show');
  void toast.offsetWidth;
  toast.classList.add('show');
  clearTimeout(showToast._t);
  showToast._t=setTimeout(()=>toast.classList.remove('show'),1800);
}

function toggleLock(locked){
  body.classList.toggle('lock-scroll', !!locked);
}

function openNav(){
  if(!nav) return;
  nav.classList.add('open');
  menuBtn?.classList.add('active');
  menuBtn?.setAttribute('aria-expanded','true');
  if(innerWidth<=980) toggleLock(true);
}
function closeNav(){
  if(!nav || !nav.classList.contains('open')) return;
  nav.classList.add('closing');
  menuBtn?.classList.remove('active');
  menuBtn?.setAttribute('aria-expanded','false');
  setTimeout(()=>{
    nav.classList.remove('open','closing');
    if(!modal?.classList.contains('open')) toggleLock(false);
  },260);
}
function toggleNav(){ nav.classList.contains('open') ? closeNav() : openNav(); }
menuBtn?.addEventListener('click',toggleNav);
qa('#nav a').forEach(a=>a.addEventListener('click',closeNav));
window.addEventListener('resize',()=>{ if(innerWidth>980){ nav?.classList.remove('closing'); toggleLock(modal?.classList.contains('open')); }});

document.addEventListener('keydown',e=>{
  if(e.key==='Escape'){
    if(nav?.classList.contains('open')) closeNav();
    if(modal?.classList.contains('open')) closeModal();
  }
});

// Scroll reveal
const io=new IntersectionObserver(es=>es.forEach(e=>{if(e.isIntersecting)e.target.classList.add('in')}),{threshold:.14});
qa('.reveal').forEach(el=>io.observe(el));

// Cursor glow + custom cursor
const glow=q('#cursorGlow'), dot=q('#cursorDot'), ring=q('#cursorRing');
let rx=0,ry=0,mx=0,my=0;
window.addEventListener('pointermove',e=>{
  mx=e.clientX; my=e.clientY;
  if(glow){glow.style.left=mx+'px'; glow.style.top=my+'px';}
  if(dot){dot.style.left=mx+'px'; dot.style.top=my+'px';}
});
(function cursorLoop(){
  rx+=(mx-rx)*.16; ry+=(my-ry)*.16;
  if(ring){ring.style.left=rx+'px'; ring.style.top=ry+'px';}
  requestAnimationFrame(cursorLoop);
})();
qa('a,button,.work-card,summary,input,select,textarea,.tool,.service,.stat').forEach(el=>{
  el.addEventListener('pointerenter',()=>body.classList.add('cursor-active'));
  el.addEventListener('pointerleave',()=>body.classList.remove('cursor-active'));
});

// 3D tilt
qa('[data-tilt]').forEach(card=>{
  card.addEventListener('pointermove',e=>{
    const r=card.getBoundingClientRect();
    const x=(e.clientX-r.left)/r.width-.5;
    const y=(e.clientY-r.top)/r.height-.5;
    card.style.transform=`perspective(900px) rotateX(${-y*5}deg) rotateY(${x*7}deg) translateY(-2px)`;
  });
  card.addEventListener('pointerleave',()=>card.style.transform='');
});

// Magnetic buttons
qa('.magnetic').forEach(btn=>{
  btn.addEventListener('pointermove',e=>{
    const r=btn.getBoundingClientRect();
    btn.style.transform=`translate(${(e.clientX-r.left-r.width/2)*.08}px,${(e.clientY-r.top-r.height/2)*.08}px)`;
  });
  btn.addEventListener('pointerleave',()=>btn.style.transform='');
});

// Global click ripple + press animation
function addRipple(el, x, y){
  const rect=el.getBoundingClientRect();
  const ripple=document.createElement('span');
  ripple.className='ripple';
  const size=Math.max(rect.width,rect.height)*1.25;
  ripple.style.width=ripple.style.height=size+'px';
  ripple.style.left=(x-rect.left-size/2)+'px';
  ripple.style.top=(y-rect.top-size/2)+'px';
  el.appendChild(ripple);
  ripple.addEventListener('animationend',()=>ripple.remove());
}
qa('a,button,.work-card,.tool,.service,.social-link,.contact-card a,.contact-card button,.filter-row button,.back-top,summary,.stat').forEach(el=>{
  el.classList.add('ripple-host');
  el.addEventListener('pointerdown',e=>{
    el.classList.add('is-pressed');
    addRipple(el,e.clientX,e.clientY);
  });
  const clear=()=>el.classList.remove('is-pressed');
  el.addEventListener('pointerup',clear);
  el.addEventListener('pointerleave',clear);
});

// Filter buttons with animated switching
const filterButtons=qa('#filters button');
filterButtons.forEach(b=>b.addEventListener('click',()=>{
  filterButtons.forEach(x=>x.classList.remove('active'));
  b.classList.add('active');
  const f=b.dataset.filter;
  qa('.work-card').forEach((c,i)=>{
    const match=f==='all'||c.dataset.cat===f;
    c.classList.remove('anim-in','anim-out');
    if(match){
      c.classList.remove('hide');
      c.style.animationDelay=`${i*45}ms`;
      c.classList.add('anim-in');
    }else{
      c.classList.add('anim-out');
      setTimeout(()=>c.classList.add('hide'),180);
    }
  });
}));

// Modal open / close animations
function openModalFromCard(c){
  modalImg.src=q('img',c).src;
  modalTitle.textContent=c.dataset.title;
  modalDesc.textContent=c.dataset.desc;
  modal.classList.remove('closing');
  modal.classList.add('open');
  modal.setAttribute('aria-hidden','false');
  toggleLock(true);
}
function closeModal(){
  if(!modal?.classList.contains('open')) return;
  modal.classList.add('closing');
  setTimeout(()=>{
    modal.classList.remove('open','closing');
    modal.setAttribute('aria-hidden','true');
    if(!nav?.classList.contains('open')) toggleLock(false);
  },260);
}
qa('.work-card').forEach(c=>{
  c.addEventListener('click',()=>openModalFromCard(c));
  c.addEventListener('keydown',e=>{ if(e.key==='Enter'||e.key===' '){e.preventDefault(); openModalFromCard(c);} });
});
q('#modalClose')?.addEventListener('click',closeModal);
modal?.addEventListener('click',e=>{ if(e.target===modal) closeModal(); });
q('#modalContact')?.addEventListener('click',closeModal);

// Copy email
q('#copyEmail')?.addEventListener('click',async()=>{
  try{ await navigator.clipboard.writeText('sohelkhan09574@gmail.com'); showToast('Email copied'); }
  catch{ showToast('sohelkhan09574@gmail.com'); }
});

// Scroll UI + parallax + header hide/show
let last=0;
const progress=q('#scrollProgress'), header=q('.site-header'), backTop=q('#backTop');
function updateScrollUI(){
  const y=window.scrollY;
  document.documentElement.style.setProperty('--scroll',y);
  if(Math.abs(y-last)>20){ body.dataset.dir=y>last?'down':'up'; last=y; }
  const max=document.documentElement.scrollHeight-innerHeight;
  const pct=max>0?(y/max)*100:0;
  if(progress) progress.style.width=pct+'%';
  header?.classList.toggle('scrolled',y>40);
  backTop?.classList.toggle('show',y>650);
  qa('[data-parallax]').forEach(el=>{
    if(innerWidth<760) return;
    const r=el.getBoundingClientRect(), speed=parseFloat(el.dataset.parallax||0);
    el.style.translate=`0 ${(-r.top*speed).toFixed(1)}px`;
  });
}
window.addEventListener('scroll',updateScrollUI,{passive:true});
updateScrollUI();
backTop?.addEventListener('click',()=>scrollTo({top:0,behavior:'smooth'}));

// Counters
const counterIO=new IntersectionObserver(entries=>entries.forEach(entry=>{
  if(!entry.isIntersecting) return;
  const el=entry.target,target=Number(el.dataset.counter||0),suffix=el.dataset.suffix||'';
  let start=null;
  function tick(t){
    start??=t;
    const p=Math.min((t-start)/900,1);
    const v=Math.round(target*(1-Math.pow(1-p,3)));
    el.textContent=v+suffix;
    if(p<1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
  counterIO.unobserve(el);
}),{threshold:.55});
qa('[data-counter]').forEach(el=>counterIO.observe(el));

// Enquiry -> WhatsApp
const enquiryForm=q('#enquiryForm'), projectMessage=q('#projectMessage'), charCount=q('#charCount');
if(projectMessage&&charCount){
  projectMessage.addEventListener('input',()=>charCount.textContent=projectMessage.value.length);
}
if(enquiryForm){
  enquiryForm.addEventListener('submit',e=>{
    e.preventDefault();
    qa('.field-error',enquiryForm).forEach(x=>x.classList.remove('field-error','shake'));
    const fd=new FormData(enquiryForm);
    const required=['name','phone','service','message'];
    let firstBad=null;
    required.forEach(k=>{
      const el=enquiryForm.elements[k];
      if(!String(fd.get(k)||'').trim()){
        el.classList.add('field-error','shake');
        firstBad=firstBad||el;
        setTimeout(()=>el.classList.remove('shake'),500);
      }
    });
    if(firstBad){ firstBad.focus(); showToast('Please fill required fields'); return; }
    const text=[
      'Hi Sohel, I want to discuss a project.',
      '',
      `Name: ${fd.get('name')}`,
      `WhatsApp: ${fd.get('phone')}`,
      `Email: ${fd.get('email')||'Not provided'}`,
      `Project Type: ${fd.get('service')}`,
      `Budget: ${fd.get('budget')||'Not specified'}`,
      `Deadline: ${fd.get('deadline')||'Not specified'}`,
      '',
      'Project Details:',
      String(fd.get('message')).trim()
    ].join('\n');
    enquiryForm.classList.add('form-success');
    setTimeout(()=>enquiryForm.classList.remove('form-success'),820);
    showToast('Opening WhatsApp…');
    window.open(`https://wa.me/917667141311?text=${encodeURIComponent(text)}`,'_blank','noopener');
  });
}

// FAQ smooth open/close
qa('.faq details').forEach(details=>{
  const summary=q('summary',details);
  const wrapper=document.createElement('div');
  wrapper.className='faq-content';
  [...details.children].forEach(child=>{ if(child!==summary) wrapper.appendChild(child); });
  details.appendChild(wrapper);
  details.removeAttribute('open');
  wrapper.style.height='0px';
  summary.addEventListener('click',e=>{
    e.preventDefault();
    const isOpen=details.classList.contains('is-open');
    qa('.faq details.is-open').forEach(other=>{ if(other!==details) animateClose(other); });
    isOpen ? animateClose(details) : animateOpen(details);
  });
});
function animateOpen(details){
  const content=q('.faq-content',details);
  details.open=true;
  details.classList.add('is-open');
  content.style.height='0px';
  requestAnimationFrame(()=> content.style.height=content.scrollHeight+'px');
  content.addEventListener('transitionend', function done(e){
    if(e.propertyName!=='height') return;
    content.style.height='auto';
    content.removeEventListener('transitionend', done);
  });
}
function animateClose(details){
  const content=q('.faq-content',details);
  content.style.height=content.scrollHeight+'px';
  requestAnimationFrame(()=> content.style.height='0px');
  details.classList.remove('is-open');
  content.addEventListener('transitionend', function done(e){
    if(e.propertyName!=='height') return;
    details.open=false;
    content.removeEventListener('transitionend', done);
  });
}

// Preloader
const preloader=q('#preloader'), loaderBar=q('#loaderBar');
let loadPct=0;
const loadTimer=setInterval(()=>{
  loadPct=Math.min(loadPct+Math.floor(Math.random()*13)+5,92);
  if(loaderBar) loaderBar.style.width=loadPct+'%';
},110);
window.addEventListener('load',()=>{
  clearInterval(loadTimer);
  if(loaderBar) loaderBar.style.width='100%';
  setTimeout(()=>{ preloader?.classList.add('out'); body.classList.remove('is-loading'); },420);
});
setTimeout(()=>{
  if(body.classList.contains('is-loading')){
    preloader?.classList.add('out');
    body.classList.remove('is-loading');
  }
},2600);
