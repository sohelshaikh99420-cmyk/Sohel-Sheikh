# Sohel Sheikh Portfolio — V2

GitHub Pages-ready single-page portfolio for a video editor & videographer.

## V2 features
- Cinematic loading intro
- Scroll progress indicator
- Smooth section reveal + blur-to-clear motion
- Hero text mask reveal
- Cursor dot/ring + ambient glow
- 3D tilt and magnetic buttons
- Subtle scroll parallax
- Animated stats counters
- Services, tools and portfolio filters
- Portfolio modal with keyboard support
- Moving cinematic marquee
- Project enquiry form that formats the brief and opens WhatsApp
- Direct WhatsApp, Instagram, Call and Email actions
- FAQ, clients, testimonials and responsive mobile navigation
- Back-to-top control
- Reduced-motion accessibility support
- No backend or paid hosting required

## Deploy on GitHub Pages
Upload everything inside this folder to the repository root, then enable **Settings → Pages → Deploy from branch → main / root**.

## Important
The enquiry form sends the user's project brief by opening WhatsApp. GitHub Pages cannot privately store enquiries by itself. If you later want an enquiry database/email inbox, connect a form service or backend.
